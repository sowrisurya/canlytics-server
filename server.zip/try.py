from subscribers.dataAdder import DataController

a = DataController(frame_id=1971, inpt_data_hex="22F190")
a.configure()
a.publish()
a.wait_for_data(timeout=100)